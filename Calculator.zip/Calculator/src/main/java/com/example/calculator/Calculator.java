package com.example.calculator;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.text.DecimalFormat;

public class Calculator extends Application {
    private BorderPane borderpane;
    private GridPane gridPane;


    TextField vbTxtField = new TextField();

    TextField vbTopTxt = new TextField();



    @Override
    public void start(Stage primaryStage) {
        borderpane = new BorderPane();
        borderpane.setStyle("-fx-background-color: lightgrey");
        Scene scene = new Scene(borderpane, 500, 310);
        primaryStage.setMinHeight(310);
        primaryStage.setMinWidth(500);

        setCalculator();


        primaryStage.setTitle("Calculator");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public void setCalculator() {
        // top section (text area and setting up grid pane)
        gridPane = new GridPane();
        VBox vbTopBox = new VBox();

        vbTopTxt.setFont(Font.font("Arial", FontWeight.NORMAL, 20));

        vbTopBox.setPadding(new Insets(10));
        vbTopBox.setSpacing(10);
        // Where the buttons will go
        VBox vbCenter = new VBox();

        //Buttons 0-9 as well as the dot on the bottom right
        Button numBtn0 = new Button("0");
        Button btnDot = new Button(".");

        Button numBtn1 = new Button("1");
        Button numBtn2 = new Button("2");
        Button numBtn3 = new Button("3");

        Button numBtn4 = new Button("4");
        Button numBtn5 = new Button("5");
        Button numBtn6 = new Button("6");

        Button numBtn7 = new Button("7");
        Button numBtn8 = new Button("8");
        Button numBtn9 = new Button("9");

        // Right side first row
        Button multiplicationBtn = new Button("X");
        Button remainderBtn = new Button("%");
        Button clearBtn = new Button("Clear");

        // Right side second row
        Button subtractionBtn = new Button("-");
        Button factorialBtn = new Button("x!");
        Button powerOfTwoBtn = new Button("X\u00B2");

        // Right side third row
        Button additionBtn = new Button("+");
        Button sqrtBtn = new Button("√2");
        Button powerOfThreeBtn = new Button("X\u00B3");

        // Right side third row
        Button divisionBtn = new Button("÷");
        Button cbrtBtn = new Button("√3");
        Button powerOfNBtn = new Button("X\u207F");

        // Styling each button; 0-9 and dot button styling sheet
        numBtn0.setStyle("-fx-background-color: white; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 140px; -fx-min-height: 10px;");
        numBtn0.setPrefWidth(20);

        btnDot.setStyle("-fx-background-color: white; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        btnDot.setPrefWidth(20);

        numBtn1.setStyle("-fx-background-color: white; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        numBtn1.setPrefWidth(20);

        numBtn2.setStyle("-fx-background-color: white; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        numBtn2.setPrefWidth(20);

        numBtn3.setStyle("-fx-background-color: white; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        numBtn3.setPrefWidth(20);

        numBtn4.setStyle("-fx-background-color: white; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        numBtn4.setPrefWidth(20);

        numBtn5.setStyle("-fx-background-color: white; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        numBtn5.setPrefWidth(20);

        numBtn6.setStyle("-fx-background-color: white; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        numBtn6.setPrefWidth(20);

        numBtn7.setStyle("-fx-background-color: white; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        numBtn7.setPrefWidth(20);

        numBtn8.setStyle("-fx-background-color: white; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        numBtn8.setPrefWidth(20);

        numBtn9.setStyle("-fx-background-color: white; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        numBtn9.setPrefWidth(20);


        // Styling each button on right side of the calculator; first row
        multiplicationBtn.setStyle("-fx-background-color: orange; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        multiplicationBtn.setPrefWidth(20);

        remainderBtn.setStyle("-fx-background-color: orange; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        remainderBtn.setPrefWidth(20);

        clearBtn.setStyle("-fx-background-color: orange; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        clearBtn.setPrefWidth(20);

        // Styling each button on right side of the calculator; second row
        subtractionBtn.setStyle("-fx-background-color: orange; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        subtractionBtn.setPrefWidth(20);

        factorialBtn.setStyle("-fx-background-color: orange; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        factorialBtn.setPrefWidth(20);

        powerOfTwoBtn.setStyle("-fx-background-color: orange; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        powerOfTwoBtn.setPrefWidth(20);

        // Styling each button on right side of the calculator; third row
        additionBtn.setStyle("-fx-background-color: orange; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        additionBtn.setPrefWidth(20);

        sqrtBtn.setStyle("-fx-background-color: orange; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        sqrtBtn.setPrefWidth(20);

        powerOfThreeBtn.setStyle("-fx-background-color: orange; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        powerOfThreeBtn.setPrefWidth(20);

        // Styling each button on right side of the calculator; fourth row
        divisionBtn.setStyle("-fx-background-color: orange; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        divisionBtn.setPrefWidth(20);

        cbrtBtn.setStyle("-fx-background-color: orange; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        cbrtBtn.setPrefWidth(20);

        powerOfNBtn.setStyle("-fx-background-color: orange; -fx-text-fill: black;" +
                "-fx-font-size: 14px; -fx-min-width: 60px; -fx-min-height: 10px;");
        powerOfNBtn.setPrefWidth(20);

        //Setting the gaps to make the buttons spaced out evenly
        gridPane.setHgap(10);
        gridPane.setVgap(10);

        //Adding all the buttons onto the grid pane
        gridPane.add(numBtn0, 0, 3, 2, 1);
        gridPane.add(btnDot, 2, 3, 2, 1);

        gridPane.add(numBtn1, 0, 2);
        gridPane.add(numBtn2, 1, 2);
        gridPane.add(numBtn3, 2, 2);

        gridPane.add(numBtn4, 0, 1);
        gridPane.add(numBtn5, 1, 1);
        gridPane.add(numBtn6, 2, 1);

        gridPane.add(numBtn7, 0, 0);
        gridPane.add(numBtn8, 1, 0);
        gridPane.add(numBtn9, 2, 0);

        //Adding all the buttons on the right
        gridPane.add(multiplicationBtn, 3, 0);
        gridPane.add(remainderBtn, 4, 0);
        gridPane.add(clearBtn, 5, 0);

        gridPane.add(subtractionBtn, 3, 1);
        gridPane.add(factorialBtn, 4, 1);
        gridPane.add(powerOfTwoBtn, 5, 1);

        gridPane.add(additionBtn, 3, 2);
        gridPane.add(sqrtBtn, 4, 2);
        gridPane.add(powerOfThreeBtn, 5, 2);

        gridPane.add(divisionBtn, 3, 3);
        gridPane.add(cbrtBtn, 4, 3);
        gridPane.add(powerOfNBtn, 5, 3);

        gridPane.setHgap(20);
        gridPane.setVgap(20);

        vbCenter.setPadding(new Insets(10));
        vbCenter.setSpacing(10);

        //Equal button
        VBox vbBottom = new VBox();
        Button equalBttn = new Button("=");
        equalBttn.setMaxWidth(Double.MIN_VALUE);

        vbBottom.setSpacing(10);
        vbBottom.setPadding(new Insets(10));
        equalBttn.setStyle("-fx-background-color: orange; -fx-text-fill: white;");
        equalBttn.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);

        //0-9 and dot button
        numBtn0.setOnMouseClicked(e -> {
            vbTxtField.appendText("0");
        });

        numBtn1.setOnMouseClicked(e -> {
            vbTxtField.appendText("1");
        });

        numBtn2.setOnMouseClicked(e -> {
            vbTxtField.appendText("2");
        });

        numBtn3.setOnMouseClicked(e -> {
            vbTxtField.appendText("3");
        });

        numBtn4.setOnMouseClicked(e -> {
            vbTxtField.appendText("4");
        });

        numBtn5.setOnMouseClicked(e -> {
            vbTxtField.appendText("5");
        });

        numBtn6.setOnMouseClicked(e -> {
            vbTxtField.appendText("6");
        });

        numBtn7.setOnMouseClicked(e -> {
            vbTxtField.appendText("7");
        });

        numBtn8.setOnMouseClicked(e -> {
            vbTxtField.appendText("8");
        });

        numBtn9.setOnMouseClicked(e -> {
            vbTxtField.appendText("9");
        });

        additionBtn.setOnMouseClicked(e -> {
            vbTxtField.appendText("+");
        });

        subtractionBtn.setOnMouseClicked(e -> {
            vbTxtField.appendText("-");
        });

        divisionBtn.setOnMouseClicked(e -> {
            vbTxtField.appendText("÷");
        });

        multiplicationBtn.setOnMouseClicked(e -> {
            vbTxtField.appendText("X");
        });

        factorialBtn.setOnMouseClicked(e -> {
            vbTxtField.appendText("!");
        });

        remainderBtn.setOnMouseClicked(e -> {
            vbTxtField.appendText("%");
        });

        sqrtBtn.setOnMouseClicked(e -> {

            squareRoot();
        });

        cbrtBtn.setOnMouseClicked(e -> {
            cubeRoot();
        });

        powerOfTwoBtn.setOnMouseClicked(e -> {
            powerOfTwo();
        });

        powerOfThreeBtn.setOnMouseClicked(e -> {
            powerOfThree();
        });

        powerOfNBtn.setOnMouseClicked(e -> {
            vbTxtField.appendText("pow");
        });


        btnDot.setOnMouseClicked(e -> {
            clearTxt();
//            vbTxtField.appendText(".");
        });

        clearBtn.setOnMouseClicked(e -> {
            clearTxt();
        });

        equalBttn.setOnAction(e -> {
            String equation = vbTxtField.getText().trim();
            if (equation.contains("+")) {
                addition();
            } else if (equation.contains("-")) {
                subtraction();
            } else if (equation.contains("÷")) {
                division();
            } else if (equation.contains("X")) {
                multiplication();
            } else if (equation.contains("%")) {
                remainder();
            } else if (equation.contains("!")) {
                factorial();
            } else if (equation.contains("pow")) {
                powerOfN();
            }

            /***continue the code here ***/
        });

        //Adding each section into the borderpane
        vbCenter.getChildren().add(gridPane);
        vbBottom.getChildren().add(equalBttn);
        vbTopBox.getChildren().addAll(vbTopTxt, vbTxtField);
        borderpane.setTop(vbTopBox);
        borderpane.setCenter(vbCenter);
        borderpane.setBottom(vbBottom);


    }

    private void showLargeResultAlert(double result) {
        vbTopTxt.clear();
        vbTxtField.clear();
        double largeNumber = 1234567890.1234567890;
        String fullPrecisionString = String.valueOf(largeNumber);
        DecimalFormat decimalFormat = new DecimalFormat("#.##########");
        String formattedResult = decimalFormat.format(result);

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Big Result");
        alert.setHeaderText(null);

        TextArea textArea = new TextArea();
        textArea.setFont(Font.font("Arial", FontWeight.NORMAL, 14));
        textArea.setText("The result is: " + formattedResult);
        textArea.setEditable(false);
        textArea.setWrapText(true);

        // Set text wrapping and content of the alert dialog with text area
        textArea.setWrapText(true); // Enable text wrapping
        alert.getDialogPane().setContent(textArea);


        Stage stage = (Stage) alert.getDialogPane().getScene().getWindow();
        // Set properties to make the dialog resizable by the user
        stage.setResizable(true);
        stage.setMinWidth(300);
        stage.setMinHeight(200);

        javafx.scene.control.DialogPane dialogPane = alert.getDialogPane();
        dialogPane.setPrefWidth(400);
        dialogPane.setPrefHeight(200);



        alert.getDialogPane().setContent(textArea);
        alert.showAndWait();




    }

    private String formatLargeResult(double result) {
        return String.format("%.2f", result);
    }

    private void showErrorMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private boolean isResultTooLarge(double result) {
        return Math.abs(result) > 1000000;

    }



    public void addition() {
        String equation = vbTxtField.getText().trim();
        vbTopTxt.setText(equation);

        String[] parts = equation.split("\\+");
        if (parts.length == 2) {
            double num1 = Double.parseDouble(parts[0]);
            double num2 = Double.parseDouble(parts[1]);
            double result = num1 + num2;


            // Perform normal operations if the result is not too large
            if (num1 == (int) num1 && num2 == (int) num2) {
                vbTopTxt.setText(parts[0] + " + " + parts[1] + " = " + (int) result);
            } else {
                vbTopTxt.setText(parts[0] + " + " + parts[1] + " = " + result);
            }
            if (isResultTooLarge(result)) {
                showLargeResultAlert(result);
            }
            vbTxtField.clear();
        }
    }


    public void subtraction() {
        String equation = vbTxtField.getText().trim();
        vbTopTxt.setText(equation);

        String[] parts = equation.split("\\-");
        if (parts.length == 2) {
            double num1 = Double.parseDouble(parts[0]);
            double num2 = Double.parseDouble(parts[1]);
            double result = num1 - num2;

            //this has the same logic as shown in the addition() method
            if (num1 == (int) num1 && num2 == (int) num2) {
                vbTopTxt.setText(parts[0] + " - " + parts[1] + " = " + (int) result);
            } else {
                vbTopTxt.setText(parts[0] + " - " + parts[1] + " = " + result);
            }
            vbTxtField.clear();
        }
    }

    public void division() {
        String equation = vbTxtField.getText().trim();
        vbTopTxt.setText(equation);

        String[] parts = equation.split("\\÷");
        if (parts.length == 2) {

            double num1 = Double.parseDouble(parts[0]);
            double num2 = Double.parseDouble(parts[1]);

            if (num2 == 0) {
                vbTopTxt.setText("Error: Division by zero");
            } else {
                double result = num1 / num2;



                if (num1 == (int) num1 && num2 == (int) num2 && result == (int) result) {
                    vbTopTxt.setText(parts[0] + " ÷ " + parts[1] + " = " + (int) result);


                } else {
                    vbTopTxt.setText(parts[0] + " ÷ " + parts[1] + " = " + result);
                }

                vbTxtField.clear();
                if (isResultTooLarge(result)) {
                    showLargeResultAlert(result);
                }
            }
        }
    }

    public void multiplication() {
        String equation = vbTxtField.getText().trim();
        vbTopTxt.setText(equation);

        String[] parts = equation.split("X");

        if (parts.length == 2) {

            double num1 = Double.parseDouble(parts[0]);
            double num2 = Double.parseDouble(parts[1]);
            double result = num1 * num2;



            if (num1 == (int) num1 && num2 == (int) num2 && result == (int) result) {
                vbTopTxt.setText(parts[0] + " X " + parts[1] + " = " + (int) result);


            } else {
                vbTopTxt.setText(parts[0] + " X " + parts[1] + " = " + result);


            }

            vbTxtField.clear();
            if (isResultTooLarge(result)) {
                showLargeResultAlert(result);
            }
        }
    }

    public void remainder() {
        String equation = vbTxtField.getText().trim();
        vbTopTxt.setText(equation);

        String[] parts = equation.split("%");

        if (parts.length == 2) {
            double num1 = Double.parseDouble(parts[0]);
            double num2 = Double.parseDouble(parts[1]);
            double result = num1 % num2;



            if (num1 == (int) num1 && num2 == (int) num2 && result == (int) result) {
                vbTopTxt.setText(parts[0] + " % " + parts[1] + " = " + (int) result);


            } else {
                vbTopTxt.setText(parts[0] + " % " + parts[1] + " = " + result);


            }
            if (isResultTooLarge(result)) {
                showLargeResultAlert(result);
            }
            vbTxtField.clear();
        }
    }

    public void factorial() {
        String equation = vbTxtField.getText().trim();
        vbTopTxt.setText(equation);

        if (equation.matches("\\d+!")) {
            int num = Integer.parseInt(equation.substring(0, equation.length() - 1));

            // Calculate the factorial
            long factorial = 1;
            for (int i = 1; i <= num; i++) {
                factorial *= i;
            }



            if (num <= 20) { // If the number is small enough to fit in an int
                vbTopTxt.setText(num + "! = " + (int) factorial);


            } else {
                vbTopTxt.setText(num + "! = " + factorial);


            }
            if (isResultTooLarge(factorial)) {
                showLargeResultAlert(factorial);
            }
            vbTxtField.clear();
        }
    }

    public void squareRoot() {
        String equation = vbTxtField.getText().trim();
        double number = Double.parseDouble(equation);

        double result = (double) Math.sqrt(number);



        if (result == (double) result) {
            vbTopTxt.setText("" + (double) result);
        } else {
            vbTopTxt.setText("" + result);
        }
        vbTxtField.clear();
        if (isResultTooLarge(result)) {
            showLargeResultAlert(result);
        }
    }


    public void cubeRoot() {
        String equation = vbTxtField.getText().trim();
        double inputNumber = Double.parseDouble(equation);

        double result = Math.cbrt(inputNumber);



        if (result == (int) result) {
            vbTopTxt.setText("" + (int) result);


        } else {
            vbTopTxt.setText("" + result);


        }
        if (isResultTooLarge(result)) {
            showLargeResultAlert(result);
        }
        vbTxtField.clear();
    }

    public void powerOfTwo() {
        String equation = vbTxtField.getText().trim();
        int finalAnswer = (int) Math.pow(Integer.parseInt(equation), 2);

        String finalString = ("" + finalAnswer);
        vbTopTxt.setText(finalString);
        vbTxtField.clear();
        if (isResultTooLarge(finalAnswer)) {
            showLargeResultAlert(finalAnswer);
        }



    }

    public void powerOfThree() {
        String equation = vbTxtField.getText().trim();
        int finalAnswer = (int) Math.pow(Integer.parseInt(equation), 3);



        String finalString = ("" + finalAnswer);
        vbTopTxt.setText(finalString);
        vbTxtField.clear();

        if (isResultTooLarge(finalAnswer)) {
            showLargeResultAlert(finalAnswer);
        }


    }

    public void powerOfN() {
        String equation = vbTxtField.getText().trim();
        vbTopTxt.setText(equation);

        // Split the equation around the power operation "^"
        String[] parts = equation.split("\\^");

        if (parts.length == 2) {

            int num1 = Integer.parseInt(parts[0]);
            int num2 = Integer.parseInt(parts[1]);
            int result = (int) Math.pow(num1, num2);



            vbTopTxt.setText(parts[0] + " ^ " + parts[1] + " = " + result);
            vbTxtField.clear();
            if (isResultTooLarge(result)) {
                showLargeResultAlert(result);
            }

        }
    }



    public void clearTxt() {
        vbTxtField.clear();
    }

    public static void main(String[] args) {
        launch(args);
    }
}


